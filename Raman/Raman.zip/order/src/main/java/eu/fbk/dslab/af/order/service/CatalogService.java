package eu.fbk.dslab.af.order.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import eu.fbk.dslab.af.order.domain.ProductObject;

@Service
public class CatalogService {

    @Autowired
    private RestTemplate restTemplate;

    public ProductObject getProductFromCatalog(String productId) {
        ProductObject product = restTemplate.getForObject(
            "http://catalog/api/products/" + productId, 
            ProductObject.class);
        return product;
    }

    public void changeProductAvailability(String productId, Integer quantity) {
        restTemplate.put("http://catalog/api/products/" + productId+"/availability/"+quantity, null);
    }
}
